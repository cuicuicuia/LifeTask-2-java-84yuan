#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_NAME_LEN 10
#define MAX_WEEKDAYS 7
#define MAX_NUM_PEOPLE 7

char *WEEK[MAX_WEEKDAYS] = {"星期天", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"};

typedef struct {
    char name[MAX_NAME_LEN];
    int day[MAX_WEEKDAYS];
} REST;

REST guard[MAX_NUM_PEOPLE] = {
    {"老钱", {0}},
    {"老赵", {0}},
    {"老孙", {0}},
    {"老李", {0}},
    {"老周", {0}},
    {"老吴", {0}},
    {"老陈", {0}}
};

void inputRestDays() {
    FILE *fp = fopen("RestDay.txt", "w");
    if (fp == NULL) {
        printf("无法打开文件\n");
        return;
    }
    for (int i = 0; i < MAX_NUM_PEOPLE; i++) {
        printf("请输入%s的休息日(0-6, 0代表星期天, 6代表星期六): ", guard[i].name);
        for (int j = 0; j < MAX_WEEKDAYS; j++) {
            scanf("%d", &guard[i].day[j]);
            if (guard[i].day[j] == 8) break; // 输入8表示结束
        }
        fprintf(fp, "%s ", guard[i].name);
        for (int j = 0; j < MAX_WEEKDAYS; j++) {
            fprintf(fp, "%d ", guard[i].day[j]);
        }
        fprintf(fp, "\n");
    }
    fclose(fp);
    printf("休息日信息已保存到文件\n");
}

void readRestDays() {
    FILE *fp = fopen("RestDay.txt", "r");
    if (fp == NULL) {
        printf("无法打开文件\n");
        return;
    }
    for (int i = 0; i < MAX_NUM_PEOPLE; i++) {
        fscanf(fp, "%s", guard[i].name);
        for (int j = 0; j < MAX_WEEKDAYS; j++) {
            fscanf(fp, "%d", &guard[i].day[j]);
        }
    }
    fclose(fp);
    printf("休息日信息已从文件读取\n");
}

int isValidSchedule(int p[]) {
    int i, j;
    for (i = 0; i < MAX_WEEKDAYS; ++i) {
        for (j = 0; j < MAX_NUM_PEOPLE && p[j] != i; ++j);
        if (j == MAX_NUM_PEOPLE)
            return 0;
    }
    return 1;
}

void generateSchedules() {
    int t = 0, j, ren[MAX_NUM_PEOPLE];
    long i;
    printf("**********************************************\n");
    printf("*  老钱, 老赵, 老孙, 老李, 老周, 老吴, 老陈  *\n");
    printf("*--------------------------------------------*\n");
    for (i = 0; i < 2097152; ++i) {
        for (j = 0; j < MAX_NUM_PEOPLE; ++j) {
            ren[j] = (i >> (3 * j)) & 7;
        }

        if (!(ren[0] == guard[0].day[0] || ren[0] == guard[0].day[1] || ren[0] == guard[0].day[2] || ren[0] == guard[0].day[3] || ren[0] == guard[0].day[4] || ren[0] == guard[0].day[5] || ren[0] == guard[0].day[6]))
            continue;
        else if (!(ren[1] == guard[1].day[0] || ren[1] == guard[1].day[1] || ren[1] == guard[1].day[2] || ren[1] == guard[1].day[3] || ren[1] == guard[1].day[4] || ren[1] == guard[1].day[5] || ren[1] == guard[1].day[6]))
            continue;
        else if (!(ren[2] == guard[2].day[0] || ren[2] == guard[2].day[1] || ren[2] == guard[2].day[2] || ren[2] == guard[2].day[3] || ren[2] == guard[2].day[4] || ren[2] == guard[2].day[5] || ren[2] == guard[2].day[6]))
            continue;
        else if (!(ren[3] == guard[3].day[0] || ren[3] == guard[3].day[1] || ren[3] == guard[3].day[2] || ren[3] == guard[3].day[3] || ren[3] == guard[3].day[4] || ren[3] == guard[3].day[5] || ren[3] == guard[3].day[6]))
            continue;
        else if (!(ren[4] == guard[4].day[0] || ren[4] == guard[4].day[1] || ren[4] == guard[4].day[2] || ren[4] == guard[4].day[3] || ren[4] == guard[4].day[4] || ren[4] == guard[4].day[5] || ren[4] == guard[4].day[6]))
            continue;
        else if (!(ren[5] == guard[5].day[0] || ren[5] == guard[5].day[1] || ren[5] == guard[5].day[2] || ren[5] == guard[5].day[3] || ren[5] == guard[5].day[4] || ren[5] == guard[5].day[5] || ren[5] == guard[5].day[6]))
            continue;
        else if (!(ren[6] == guard[6].day[0] || ren[6] == guard[6].day[1] || ren[6] == guard[6].day[2] || ren[6] == guard[6].day[3] || ren[6] == guard[6].day[4] || ren[6] == guard[6].day[5] || ren[6] == guard[6].day[6]))
            continue;
        else if (!isValidSchedule(ren))
            continue;

        for (j = 0; j < MAX_NUM_PEOPLE; ++j) {
            printf("%s ", WEEK[ren[j]]);
        }
        printf("   *\n");
        ++t;
    }
    printf("**********************************************\n");
}

int main() {
    int choice;
    while (1) {
        printf("保安休息日排班系统\n");
        printf("1. 输入休息日信息并存入文件\n");
        printf("2. 读取文件信息并生成轮休方案\n");
        printf("3. 退出\n");
        printf("请选择相应的数字: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                inputRestDays();
                break;
            case 2:
                readRestDays();
                generateSchedules();
                break;
            case 3:
                exit(0);
            default:
                printf("无效选择，请重新输入\n");
        }
    }
    return 0;
}
// +--------------------------------------+
// |          generateSchedules           |
// +--------------------------------------+
//                 |
//                 v
// +--------------------------------------+
// | 初始化变量 t = 0, j, ren[MAX_NUM_PEOPLE] |
// +--------------------------------------+
//                 |
//                 v
// +--------------------------------------+
// | 循环 i 从 0 到 2097152               |
// +--------------------------------------+
//                 |
//                 v
// +--------------------------------------+
// |   内部循环 j 从 0 到 MAX_NUM_PEOPLE  |
// |   计算 ren[j] = (i >> (3 * j)) & 7   |
// +--------------------------------------+
//                 |
//                 v
// +--------------------------------------+
// | 检查每个保安的休息日是否符合条件     |
// |   如果不符合条件，继续下一个 i       |
// +--------------------------------------+
//                 |
//                 v
// +--------------------------------------+
// | 调用 isValidSchedule 函数检查方案    |
// |   如果不符合条件，继续下一个 i       |
// +--------------------------------------+
//                 |
//                 v
// +--------------------------------------+
// | 打印符合条件的方案                   |
// +--------------------------------------+
//                 |
//                 v
// +--------------------------------------+
// | 方案计数 t 增加                      |
// +--------------------------------------+
//                 |
//                 v
// +--------------------------------------+
// | 循环结束                             |
// +--------------------------------------+
//                 |
//                 v
// +--------------------------------------+
// | 打印分隔线                           |
// +--------------------------------------+
//                 |
//                 v
// +--------------------------------------+
// | 结束 (End)                           |
// +--------------------------------------+